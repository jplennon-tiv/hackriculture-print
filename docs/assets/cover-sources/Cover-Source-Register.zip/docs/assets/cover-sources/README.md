# Cover originals and reconstruction register

16 November 2026. John requested careful tracking of all originals after accepting
the improvement in the separate artwork-restoration proof. This register covers
the numbered fronts, their retained development sources and the revision 07 back.
It does not replace the [handover](../../handover/START-HERE.md#resume-here) as the
owner of current choices or grant production approval.

[Exact file inventory](MANIFEST.json) · [Read-only verifier](verify.py) ·
[Verification result](CHECKS.json)

## Start with these originals

| Component | Original to use | Provenance / reconstruction |
| --- | --- | --- |
| Tomato drawing | [Separate transparent illustration](../../publication/cover-refined-direction/revision-13-photo-seeded-illustrations/tomato-illustration.png) | [Original photo frame](../../publication/summer-cover-photo-search/selected-stills/P01-tomato-trusses.png), [seed crops and prompts](../../publication/cover-refined-direction/revision-13-photo-seeded-illustrations/GENERATION.json), [placements](../../publication/cover-refined-direction/revision-13-photo-seeded-illustrations/LAYOUT.json). This is the clean drawing before successive full-cover edits. |
| Two-fruit courgette drawing | [Separate illustration with leaf hiding the stem base](../../publication/cover-refined-direction/revision-19-courgette-leaf/courgette-02-leaf-illustration.png) | [Thomas Parker source photograph](../../publication/cover-courgette-source-search/sources/02-overlapping-fruits-Thomas-Parker.jpg), [photo credit and licence links](../../publication/cover-courgette-source-search/SOURCES.json), [leaf-edit prompt](../../publication/cover-refined-direction/revision-19-courgette-leaf/GENERATION.json), [placement and seam correction](../../publication/cover-refined-direction/revision-19-courgette-leaf/LAYOUT.json). The earlier source-02 drawing and rejected source-01 trial are retained. |
| Courgette flowers, Versions 2–3 | [Original photograph](../../publication/summer-cover-photo-search/selected-stills/P04-courgette-flower.jpeg) and [separate drawing](../../publication/cover-refined-direction/revision-13-photo-seeded-illustrations/courgette-illustration.png) | [Photo catalogue](../../publication/summer-cover-photo-search/SHORTLIST.json) identifies DSC08469.jpeg; original JPEG bytes are retained locally. |
| Garlic, Version 5 | [Original pair of bulbs](../../publication/cover-refined-direction/revision-14-three-square-panels/garlic-source.jpeg) and [separate drawing](../../publication/cover-refined-direction/revision-14-three-square-panels/garlic-illustration.png) | [Crop, sources and placement](../../publication/cover-refined-direction/revision-14-three-square-panels/LAYOUT.json), [prompts](../../publication/cover-refined-direction/revision-14-three-square-panels/GENERATION.json). DSC09815.jpeg is retained locally; no connected drive is needed to reuse it. |
| Traditional / Metric stickers | [Original transparent black-and-gold pair](../../../generated_images/exec-80f08576-e40d-49ec-acf9-35b9e80c42d4.png) | [Prompt and source record](../../publication/edition-stickers/revision-02-black-gold/ARTWORK.json). Both circles are on one raster sheet; individual vector stickers have not been built. |
| Lettering and original YouTube badge | [Version 1 source image](../../publication/cover-versions/version-1/Version-1.png) | Early native compositions clip the centre and badge from this image. Their polygons are in the revision 11/13 layout records. These are raster lettering, not editable text. |
| Final YouTube badge and red ribbon | [Saved Version 6-2](../../publication/cover-versions/version-6-2/Version-6-2.png) | [Badge cleanup](../../publication/edition-stickers/revision-05-youtube-cleanup/ARTWORK.json), [ribbon history](../../publication/cover-refined-direction/revision-28-organic-ribbon/ARTWORK.json). Both remain flattened into the cover; no separate cleaned badge/ribbon original exists. |
| Drawing-style references | [Tomato](../../../public/images/heroes/richer-a/tomato-greenhouse.png), [courgette](../../../public/images/heroes/richer-a/marrow_courgette.png), [capsicum](../../../public/images/heroes/richer-a/capsicum.png) | Use these actual approved heroes with the separate cover drawings when comparing future artwork. Garlic/cabbage references used in earlier trials are also inventoried. |
| Font files | [Local font definitions](../../../src/print/local-fonts.css) | Lilita One and Nunito Sans WOFF2 files are recorded. The revision 07 native back uses Lilita One. Fonts alone cannot reproduce generated front letterforms exactly. |
| Retained back | [Revision 07 source and build record](../../publication/cover-refined-direction/revision-07/README.md) | Original T05 photo, approved Carrot spread, copy-bearing Swift composition, font and verification script are registered. |

## Saved versions and their lineage

| Saved version | Reconstruction record |
| --- | --- |
| 1 | [Frozen image and provenance](../../publication/cover-versions/version-1/VERSION.json); photorealistic generated strips with retained centre and sticker. |
| 2 | [Frozen PDF](../../publication/cover-versions/version-2/Version-2.pdf); [native photo assembly](../../publication/cover-refined-direction/revision-12-flowers-tomatoes/build.py). |
| 3 | [Current cream version](../../publication/cover-versions/version-3/VERSION.json); [cream edit](../../publication/cover-refined-direction/revision-27-version3-cream/GENERATION.json). The original pale-green native PDF and separate drawings are preserved. |
| 4 | [Frozen PDF and provenance](../../publication/cover-versions/version-4/VERSION.json); revision 19 composition with the two-fruit courgette. |
| 5 | [Frozen image/PDF](../../publication/cover-versions/version-5/VERSION.json); quieter top → title flow → upper title → proportion refinement, revisions 16 and 20–22. |
| 6 | [Frozen image/PDF](../../publication/cover-versions/version-6/VERSION.json); original Version 4 → retained 4a trials → offset title → text grouping → raised sticker, revisions 23–26. |
| 6-1 | [Frozen image/PDF](../../publication/cover-versions/version-6-1/VERSION.json); Version 6 plus red organic ribbon. |
| 6-2 | [Frozen image/PDF](../../publication/cover-versions/version-6-2/VERSION.json); 6-1 plus small inset-left Traditional sticker and cleaned YouTube face/edge. |
| Separate restoration proof | [Exact sources, prompt and diagnostics](../../publication/cover-artwork-restoration/ARTWORK.json); original tomato/courgette drawings and house-style references guide the redraw. John says “That's better”; it has not replaced saved 6-2. |

The [1–6 collection builder](../../publication/cover-versions/front-cover-collection/build.py)
and [6 / 6-1 / 6-2 builder](../../publication/cover-versions/versions-6-comparison/build.py)
are retained with their delivered PDFs and checks. Exact frozen images/PDFs are
the authority for reproducing a saved design. Generation prompts document intent
and references; rerunning them will not reproduce identical pixels.

## Preservation and future work

- Keep every inventoried original, generated source and frozen version in place.
  Make new revisions separately. Do not resave an original to apply an edit.
- Before editing, run `python3 docs/assets/cover-sources/verify.py`. It reads files
  and reports missing/changed bytes; it never repairs, overwrites or updates hashes.
- Historical `build.py` scripts can write into saved-version folders. Inspect and
  redirect outputs before reusing them. No builder was run for this inventory.
- Add each new asset and its source relationship to the manifest when created;
  record intentional replacements separately rather than silently accepting drift.
- Retained local photographs/stills are sufficient for the selected compositions.
  External camera paths and seek times are provenance, not checked or required
  drive dependencies. Original long videos have not been duplicated into this set.
- This is an index and integrity check, not an independent backup. It does not
  establish a final layered cover master. Current full-cover rasters are around
  151 dpi at 185 × 240 mm; final native type, ribbon and sticker layers remain
  to be assembled from these references without repeatedly redrawing the cover.

The manifest deliberately includes historical trials within this numbered-cover
development, so an intermediate original is not mistaken for disposable preview
material. Older selected G2/B5 and A4 sources remain in the parent asset registry.
